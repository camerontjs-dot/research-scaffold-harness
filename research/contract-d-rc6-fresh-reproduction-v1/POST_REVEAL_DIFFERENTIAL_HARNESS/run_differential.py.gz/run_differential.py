from __future__ import annotations
import copy, json, os, subprocess, sys
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
H=ROOT/'harness'; REF=ROOT/'reference'
VALID=json.loads((REF/'fixtures/valid.json').read_text())['fixtures']
CONF=json.loads((REF/'conformance-cases.json').read_text())['cases']

cases=[]
def add(id, action, comparator, authority_expected=None, authority_relevant=True, **kw):
    c={'id':id,'action':action,'comparator':comparator,'authority_relevant':authority_relevant,**kw}
    if authority_expected is not None: c['authority_expected']=authority_expected
    cases.append(c)

def mset(path,value): return {'op':'set','path':path,'value':value}
def mdel(path): return {'op':'delete','path':path}

# Structural/version behavior, public fixtures, exact unknown handling.
for name in sorted(VALID): add(f'struct.valid.{name}','validate','accept',True,fixture=name)
invalid_names=['actor-injection-top-level.json','effect-on-failure.json','numeric-contract-version.json','unknown-contract-version.json','unknown-evaluation-state.json','unknown-disposition.json','unknown-effect-type.json','unknown-effect-version.json','unknown-effect-parameter.json','unknown-structural-field.json']
for name in invalid_names: add(f'struct.invalid.{name}','validate','accept',False,fixture=name)
for label,value in [('rc5','0.3.0-rc5'),('alias','v0.3.0-rc6'),('case','0.3.0-RC6'),('numeric_string','0.3.0-rc06')]:
    add(f'version.reject.{label}','validate','accept',False,fixture='source-audit-clear.json',mutations=[mset(['contract_d_version'],value)])
for label,path in [
 ('top',['authorization']),('input',['input_authority','actor']),('policy',['policy','approval']),('target',['target','execution']),('evaluation',['evaluation','delegation']),('effect',['effect','actor']),('effect_params',['effect','params','actor']),('metadata',['metadata','approval'])]:
    add(f'structure.extra.{label}','validate','accept',False,fixture='source-audit-clear.json',mutations=[mset(path, True if path[-1] not in ('actor',) else 'root')])
add('completed.missing_effect','validate','accept',False,fixture='source-audit-clear.json',mutations=[mdel(['effect'])])
add('completed.missing_disposition','validate','accept',False,fixture='source-audit-clear.json',mutations=[mdel(['evaluation','disposition'])])
add('failed.with_disposition','validate','accept',False,fixture='evaluation-failed.json',mutations=[mset(['evaluation','disposition'],'hold')])
add('failed.with_effect','validate','accept',False,fixture='evaluation-failed.json',mutations=[mset(['effect'],{'type':'knowledge.add_verified_tag','version':'1'})])

# Registered effect normalization.
effects=[
 ('cite.omitted',{'type':'knowledge.cite_as_evidence','version':'1'},{'type':'knowledge.cite_as_evidence','version':'1','params':{}}),
 ('cite.empty',{'type':'knowledge.cite_as_evidence','version':'1','params':{}},{'type':'knowledge.cite_as_evidence','version':'1','params':{}}),
 ('dispatch.omitted',{'type':'task.dispatch','version':'1'},{'type':'task.dispatch','version':'1','params':{}}),
 ('dispatch.empty',{'type':'task.dispatch','version':'1','params':{}},{'type':'task.dispatch','version':'1','params':{}}),
 ('tag.omitted',{'type':'knowledge.add_verified_tag','version':'1'},{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'claim'}}),
 ('tag.empty',{'type':'knowledge.add_verified_tag','version':'1','params':{}},{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'claim'}}),
 ('tag.claim',{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'claim'}},{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'claim'}}),
 ('tag.object',{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'object'}},{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'object'}}),
]
for label,e,expected in effects: add(f'effect.{label}','normalize_effect','effect',expected,effect=e)
for label,e in [
 ('unknown_type',{'type':'future.effect','version':'1'}),('unknown_version',{'type':'task.dispatch','version':'2'}),('unknown_param',{'type':'task.dispatch','version':'1','params':{'actor':'root'}}),('bad_scope',{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'future'}})]:
    add(f'effect.reject.{label}','normalize_effect','accept',False,effect=e)

# Semantic projection/identity RC6 clarification and metadata firewall.
semantic_cases=[
 ('cite.omitted','citation-use-clear.json',[]),('cite.empty','citation-use-clear.json',[mset(['effect','params'],{})]),
 ('dispatch.omitted','task-dispatch-clear.json',[]),('dispatch.empty','task-dispatch-clear.json',[mset(['effect','params'],{})]),
 ('tag.claim','source-audit-clear.json',[]),('tag.omitted','source-audit-clear.json',[mdel(['effect','params'])]),
 ('tag.empty','source-audit-clear.json',[mset(['effect','params'],{})]),('tag.object','source-audit-object-scope-clear.json',[]),
 ('failed','evaluation-failed.json',[])
]
for label,fixture,muts in semantic_cases: add(f'semantic.{label}','semantic','semantic',None,fixture=fixture,mutations=muts)
add('firewall.metadata.authorization','metadata_identity','metadata_identity',True,fixture='source-audit-clear.json',mode='replace',diagnostics={'actor':'root','approval':True,'delegation':'all','execution_permission':True,'execution_receipt':'fake'})
add('firewall.metadata.remove','metadata_identity','metadata_identity',True,fixture='source-audit-clear.json',mode='remove')
add('firewall.top_requested_operation','validate','accept',False,fixture='source-audit-clear.json',mutations=[mset(['requested_operation'],'task.dispatch')])
for fld in ['actor','approval','delegation','execution_permission']:
    add(f'firewall.top.{fld}','validate','accept',False,fixture='source-audit-clear.json',mutations=[mset([fld], True if fld!='actor' else 'root')])

# Consumer outcomes and exact applicability substitutions.
for name in ['source-audit-clear.json','citation-use-clear.json','task-dispatch-clear.json']:
    add(f'consume.clear.{name}','consume','outcome','candidate_for_authorization',fixture=name,expectation={})
add('consume.hold.valid','consume','outcome','hold',fixture='completed-hold.json',expectation={})
add('consume.failed.valid','consume','outcome','evaluation_failed',fixture='evaluation-failed.json',expectation={'requested_operation':'knowledge.add_verified_tag'})
subs=[
 ('upstream.kind',['input_authority','kind'],'other-kind'),('upstream.id',['input_authority','id'],'other'),('upstream.immutable',['input_authority','immutable_id'],'result-set:'+'f'*64),
 ('policy.id',['policy','id'],'other.policy'),('policy.version',['policy','version'],'2'),
 ('target.kind',['target','kind'],'task'),('target.id',['target','id'],'other'),('target.hash',['target','content_sha256'],'sha256:'+'2'*64),
]
for label,path,val in subs:
    add(f'applicability.{label}','consume','outcome','not_applicable',fixture='source-audit-clear.json',expectation={'mutations':[mset(path,val)]})
add('applicability.operation.clear','consume','outcome','not_applicable',fixture='source-audit-clear.json',expectation={'requested_operation':'task.dispatch'})
add('applicability.operation.hold','consume','outcome','not_applicable',fixture='completed-hold.json',expectation={'requested_operation':'task.dispatch'})
add('params.absent.unconstrained','consume','outcome','candidate_for_authorization',fixture='source-audit-object-scope-clear.json',expectation={})
add('params.empty.unconstrained','consume','outcome','candidate_for_authorization',fixture='source-audit-object-scope-clear.json',expectation={'effect_params_mode':'explicit','effect_params':{}})
add('params.explicit.object.match','consume','outcome','candidate_for_authorization',fixture='source-audit-object-scope-clear.json',expectation={'effect_params_mode':'explicit','effect_params':{'scope':'object'}})
add('params.explicit.claim.conflict','consume','outcome','not_applicable',fixture='source-audit-object-scope-clear.json',expectation={'effect_params_mode':'explicit','effect_params':{'scope':'claim'}})
add('params.hold.conflict','consume','outcome','not_applicable',fixture='completed-hold.json',expectation={'effect_params_mode':'explicit','effect_params':{'scope':'object'}})
# Conformance corpus exactly.
for cc in CONF:
    e=cc['expect']; spec={'requested_operation':e['requested_operation']}
    if 'effect_params' in e: spec|={'effect_params_mode':'explicit','effect_params':e['effect_params']}
    # Expected binding may differ from fixture; encode exact mapping changes.
    muts=[]
    for root,keys in [('input_authority',['kind','id','immutable_id']),('policy',['id','version']),('target',['kind','id','content_sha256'])]:
        for k in keys:
            actual=VALID[cc['decision_fixture']][root][k]; wanted=e[root][k]
            if actual!=wanted: muts.append(mset([root,k],wanted))
    if muts: spec['mutations']=muts
    add(f'conformance.{cc["id"]}','consume','outcome',cc['outcome'],fixture=cc['decision_fixture'],expectation=spec)
# malformed expectations; invalid_expectation reason is normative.
add('expectation.missing_policy_version','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'mutations':[mdel(['policy','version'])]})
add('expectation.extra_policy','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'mutations':[mset(['policy','approval'],True)]})
add('expectation.bad_target_hash','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'mutations':[mset(['target','content_sha256'],'not-a-sha256')]})
add('expectation.nonfinite_params','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'special':'nonfinite_params'})
add('expectation.host_only_params','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'special':'host_only_params'})
add('expectation.surrogate_operation','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'special':'surrogate_operation'})
add('expectation.params_array','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'effect_params_mode':'explicit','effect_params':[]})
add('expectation.cyclic_params','consume','invalid_expectation',{'outcome':'cannot_establish','reason':'invalid_expectation'},fixture='source-audit-clear.json',expectation={'special':'cycle_params'})
add('params.unknown_constraint','consume','outcome','not_applicable',fixture='source-audit-clear.json',expectation={'effect_params_mode':'explicit','effect_params':{'actor':'root'}})

# Interoperable JSON special host structures and exact depth boundary.
add('json.self_cycle','finite_special','accept',False,kind='self_cycle')
add('json.mutual_cycle','finite_special','accept',False,kind='mutual_cycle')
add('json.shared_acyclic','finite_special','accept',True,kind='shared')
add('json.nonfinite','finite_special','accept',False,kind='nonfinite')
add('json.surrogate','finite_special','accept',False,kind='surrogate')
add('json.unsafe_host_integer','finite_special','named_reject','non_interoperable_integer',kind='unsafe_integer',number='9007199254740992')
# Root decision depth=1, metadata=2, diagnostics=3, so 125 nested lists ends at depth 128; 126 exceeds.
add('json.decision_depth_128','decision_depth','accept',True,nested_count=125)
add('json.decision_depth_129','decision_depth','named_reject','json_depth_exceeded',nested_count=126)
add('json.invalid_utf8','parse_raw','accept',False,hex='ff')
add('consumer.failclosed.cycle','consume_special','outcome','cannot_establish',kind='cycle')
add('consumer.failclosed.surrogate','consume_special','outcome','cannot_establish',kind='surrogate')
add('consumer.failclosed.nonfinite','consume_special','outcome','cannot_establish',kind='nonfinite')
add('consumer.failclosed.depth','consume_special','outcome','cannot_establish',kind='depth',nested_count=126)
add('json.duplicate_keys','parse_raw','accept',False,raw='{"contract_d_version":"0.3.0-rc6","contract_d_version":"0.3.0-rc6"}')

# U2 byte-ingress numeric mapping.
for label,token,expected in [
 ('safe_max','9007199254740991',True),('exact_2p53','9007199254740992',True),('precision_loss_2p53p1','9007199254740993',False),
 ('canonical_2p68','295147905179352830000',True),('exp_1e30','1e30',True),('exp_1e21','1e21',True),('fixed_1e20','1e20',True),
 ('small_1e-7','1e-7',True),('fixed_1e-6','1e-6',True),('negative_zero','-0',True),('exp_1e23','1e23',True),('neg_exp','-1e30',True),
 ('exact_2p68_decimal','295147905179352825856',True),('precision_loss_2p68_neighbor','295147905179352830001',False),('precision_loss_1e20_neighbor','100000000000000000001',False),('exact_even_2p53plus2','9007199254740994',True),('precision_loss_2p53plus3','9007199254740995',False)]:
    comp='named_reject' if not expected else 'parse_accept_canon'
    exp='non_interoperable_integer' if not expected else True
    add(f'u2.bytes.{label}','raw_numeric_token',comp,exp,token=token)
# U2 host-side integer semantics. Use Python int for normative host-integer comparison.
add('u2.host.safe_max','host_number','accept',True,number='9007199254740991',reference_kind='int')
add('u2.host.integer_2p53','host_number','named_reject','non_interoperable_integer',number='9007199254740992',reference_kind='int')
add('u2.host.integer_2p68','host_number','named_reject','non_interoperable_integer',number='295147905179352825856',reference_kind='int')
# Cross-language representation probe: JS single Number versus Python float. Public wording is host-type dependent.
add('u2.host.cross_language_float_2p53','host_number','host_mapping',None,authority_relevant=False,number='9007199254740992',reference_kind='float')
add('u2.host.cross_language_float_1e30','host_number','host_mapping',None,authority_relevant=False,number='1e30',reference_kind='float')

# U3 bounded deterministic RFC 8785 finite binary64 edge set, exercised through byte ingress.
jcs=[
 ('zero','0'),('negzero','-0'),('minsub','5e-324'),('negminsub','-5e-324'),('maxfinite','1.7976931348623157e+308'),('negmaxfinite','-1.7976931348623157e+308'),
 ('2p53','9007199254740992'),('neg2p53','-9007199254740992'),('2p68','295147905179352830000'),('edge23low','9.999999999999997e+22'),('1e23','1e+23'),('edge23high','1.0000000000000001e+23'),
 ('e20low','999999999999999700000'),('e20mid','999999999999999900000'),('1e21','1e+21'),('e-6low','9.999999999999997e-7'),('1e-6','0.000001'),
 ('third1','333333333.3333332'),('third2','333333333.33333325'),('third3','333333333.3333333'),('third4','333333333.3333334'),('third5','333333333.33333343'),
 ('negative_small','-0.0000033333333333333333'),('precision','1424953923781206.2')]
for label,token in jcs: add(f'u3.jcs.{label}','raw_numeric_token','parse_accept_canon',True,token=token)

# U1 explicit internal-label probes. Authority controls reject/accept, but not these labels unless separately named.
for id,action,kw in [
 ('u1.cycle','finite_special',{'kind':'self_cycle'}),
 ('u1.duplicate','parse_raw',{'raw':'{"a":1,"a":2}'}),
 ('u1.target_hash','validate',{'fixture':'source-audit-clear.json','mutations':[mset(['target','content_sha256'],'bad')]}),
 ('u1.missing_effect','validate',{'fixture':'source-audit-clear.json','mutations':[mdel(['effect'])]}),
 ('u1.invalid_effect_param','normalize_effect',{'effect':{'type':'knowledge.add_verified_tag','version':'1','params':{'scope':'bad'}}}),
]: add(id,action,'u1_label',False,authority_relevant=False,**kw)

# Build one raw canonicalization case proving UTF-16 non-BMP key order and metadata transport invariance.
d=copy.deepcopy(VALID['source-audit-clear.json']); d['metadata']['diagnostics']={'\uffff':1,'💩':2}
add('json.nonbmp_key_order','parse_raw','parse_accept_canon',True,raw=json.dumps(d,separators=(',',':'),ensure_ascii=False))

# Run frozen implementations independently.
payload=json.dumps(cases,separators=(',',':'),ensure_ascii=False).encode()
node=subprocess.run(['node',str(H/'node_driver.mjs')],input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
env=os.environ.copy(); env['PYTHONPATH']=str(REF/'vendor')+os.pathsep+str(REF)
ref=subprocess.run([sys.executable,str(H/'reference_driver.py')],input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,env=env)
if node.returncode or ref.returncode:
    raise SystemExit(f'driver failure node={node.returncode} {node.stderr.decode()} ref={ref.returncode} {ref.stderr.decode()}')
no={x['id']:x['observation'] for x in json.loads(node.stdout)}
ro={x['id']:x['observation'] for x in json.loads(ref.stdout)}

def norm(c,o):
    comp=c['comparator']
    if comp=='accept': return bool(o.get('accepted'))
    if comp=='named_reject': return o.get('error') if not o.get('accepted') else '__ACCEPTED__'
    if comp=='effect': return o.get('effect') if o.get('accepted') else {'error':o.get('error')}
    if comp=='semantic': return {k:o.get(k) for k in ('accepted','projection','identity','canonical_projection_hex')}
    if comp=='outcome': return o.get('outcome')
    if comp=='invalid_expectation': return {'outcome':o.get('outcome'),'reason':o.get('reason')}
    if comp=='parse_accept_canon': return {'accepted':o.get('accepted'),'canonical_hex':o.get('canonical_hex')} if o.get('accepted') else {'accepted':False,'error':o.get('error')}
    if comp=='metadata_identity': return {'accepted':o.get('accepted'),'same':o.get('same'),'identity_a':o.get('identity_a'),'identity_b':o.get('identity_b')}
    if comp in ('u1_label','host_mapping'): return o
    raise ValueError(comp)

def expected_norm(c):
    e=c.get('authority_expected')
    comp=c['comparator']
    if comp=='accept': return bool(e)
    if comp=='named_reject': return e
    if comp=='effect': return e
    if comp=='outcome': return e
    if comp=='invalid_expectation': return e
    if comp=='metadata_identity': return None
    if comp=='parse_accept_canon': return None
    return None

rows=[]
for c in cases:
    n=no[c['id']]; r=ro[c['id']]; nn=norm(c,n); rr=norm(c,r); equal=(nn==rr)
    classification='AUTHORITY_RELEVANT_AGREEMENT'; authority_agreement=True; notes=[]
    if c['comparator']=='u1_label':
        # Both should reject; label equality itself is deliberately non-normative.
        if (not n.get('accepted')) and (not r.get('accepted')):
            if n.get('error')!=r.get('error'):
                classification='NON_AUTHORITY_DIFFERENCE'; authority_agreement=True; notes.append('internal error-label difference only')
            else: classification='AUTHORITY_RELEVANT_AGREEMENT'
        else:
            classification='INCONCLUSIVE'; authority_agreement=False
    elif c['comparator']=='host_mapping':
        if equal:
            classification='AUTHORITY_RELEVANT_AGREEMENT'; authority_agreement=True
        else:
            classification='NON_AUTHORITY_DIFFERENCE'; authority_agreement=True; notes.append('language-specific host type surface: JavaScript Number vs Python float')
    elif equal:
        # For expected exact effects/outcomes/rejections, ensure both match public expectation where encoded.
        exp=expected_norm(c)
        if exp is not None:
            if c['comparator']=='named_reject': ok=(nn==exp)
            elif c['comparator']=='effect': ok=(nn==exp)
            elif c['comparator']=='invalid_expectation': ok=(nn==exp)
            else: ok=(nn==exp)
            if not ok:
                classification='INCONCLUSIVE'; authority_agreement=False; notes.append('implementations agree with each other but not encoded public expectation')
    else:
        exp=expected_norm(c)
        nmatch=rmatch=None
        if exp is not None:
            nmatch=(nn==exp); rmatch=(rr==exp)
        if nmatch is True and rmatch is False: classification='REFERENCE_IMPLEMENTATION_DEFECT'; authority_agreement=False
        elif rmatch is True and nmatch is False: classification='INDEPENDENT_IMPLEMENTATION_DEFECT'; authority_agreement=False
        else: classification='PUBLIC_AUTHORITY_AMBIGUITY'; authority_agreement=False
    rows.append({
      'case_id':c['id'],'action':c['action'],'input_mode':'JSON-byte ingress' if c['action'] in ('parse_raw','raw_numeric_token') else 'programmatic host value',
      'public_authority_expectation':c.get('authority_expected'),'independent_frozen_result':n,'reference_result':r,
      'normalized_independent':nn,'normalized_reference':rr,'agreement':equal,'authority_relevance':c['authority_relevant'],
      'classification':classification,'notes':notes,
      'case':{k:v for k,v in c.items() if k not in ('comparator','authority_relevant')}
    })

# Cross-case semantic relationships demanded by RC6 clarification.
idx={x['case_id']:x for x in rows}
def synth(id, left, right, relation, expected):
    nl=no[left].get('identity'); nr=no[right].get('identity'); rl=ro[left].get('identity'); rr=ro[right].get('identity')
    ni=(nl==nr); ri=(rl==rr); good=(ni==expected and ri==expected and nl==rl and nr==rr)
    rows.append({'case_id':id,'action':'semantic_identity_relationship','input_mode':'programmatic host value','public_authority_expectation':relation,
      'independent_frozen_result':{'left':nl,'right':nr,'relation_holds':ni},'reference_result':{'left':rl,'right':rr,'relation_holds':ri},
      'normalized_independent':ni,'normalized_reference':ri,'agreement':ni==ri,'authority_relevance':True,
      'classification':'AUTHORITY_RELEVANT_AGREEMENT' if good else ('INDEPENDENT_IMPLEMENTATION_DEFECT' if ri==expected and ni!=expected else 'REFERENCE_IMPLEMENTATION_DEFECT' if ni==expected and ri!=expected else 'PUBLIC_AUTHORITY_AMBIGUITY'),
      'notes':[],'case':{'left':left,'right':right,'expected_relation':relation}})
synth('rc6.identity.cite.omitted_equals_empty','semantic.cite.omitted','semantic.cite.empty','equal',True)
synth('rc6.identity.dispatch.omitted_equals_empty','semantic.dispatch.omitted','semantic.dispatch.empty','equal',True)
synth('rc6.identity.tag.omitted_equals_claim','semantic.tag.omitted','semantic.tag.claim','equal',True)
synth('rc6.identity.tag.empty_equals_claim','semantic.tag.empty','semantic.tag.claim','equal',True)
synth('rc6.identity.tag.object_distinct','semantic.tag.object','semantic.tag.claim','distinct',False)

counts=Counter(r['classification'] for r in rows)
all_classes=['AUTHORITY_RELEVANT_AGREEMENT','AUTHORITY_RELEVANT_DISAGREEMENT','PUBLIC_AUTHORITY_AMBIGUITY','INDEPENDENT_IMPLEMENTATION_DEFECT','REFERENCE_IMPLEMENTATION_DEFECT','NON_AUTHORITY_DIFFERENCE','EVALUATOR_OR_HARNESS_DEFECT','ENVIRONMENT_OR_DEPENDENCY_FAILURE','INCONCLUSIVE']
summary={
 'comparison_count':len(rows),'classification_counts':{k:counts.get(k,0) for k in all_classes},
 'authority_relevant_disagreements':[r['case_id'] for r in rows if r['classification'] in ('AUTHORITY_RELEVANT_DISAGREEMENT','INDEPENDENT_IMPLEMENTATION_DEFECT','REFERENCE_IMPLEMENTATION_DEFECT')],
 'public_authority_ambiguities':[r['case_id'] for r in rows if r['classification']=='PUBLIC_AUTHORITY_AMBIGUITY'],
 'non_authority_differences':[r['case_id'] for r in rows if r['classification']=='NON_AUTHORITY_DIFFERENCE'],
 'u1':[r['case_id'] for r in rows if r['case_id'].startswith('u1.')],
 'u2':[r['case_id'] for r in rows if r['case_id'].startswith('u2.')],
 'u3_count':sum(r['case_id'].startswith('u3.') for r in rows),
}
import hashlib
def compact_value(v):
    if isinstance(v,dict):
        out={}
        for k,x in v.items():
            if k.endswith('_hex') and isinstance(x,str):
                b=bytes.fromhex(x); stem=k[:-4]
                out[stem+'_sha256']=hashlib.sha256(b).hexdigest(); out[stem+'_byte_length']=len(b)
            else: out[k]=compact_value(x)
        return out
    if isinstance(v,list): return [compact_value(x) for x in v]
    return v
compact_rows=[]
for r in rows:
    q={k:v for k,v in r.items() if k not in ('normalized_independent','normalized_reference')}
    compact_rows.append(compact_value(q))
outdir=ROOT/'DIFFERENTIAL_RESULTS'
outdir.mkdir(exist_ok=True)
for oldfile in outdir.glob('chunk-*.json'):
    oldfile.unlink()
chunk_meta=[]
chunk_size=20
for i in range(0,len(compact_rows),chunk_size):
    chunk=compact_rows[i:i+chunk_size]
    name=f'chunk-{i//chunk_size:03d}.json'
    payload=json.dumps({'results':chunk},separators=(',',':'),ensure_ascii=False)+'\n'
    (outdir/name).write_text(payload)
    chunk_meta.append({'file':name,'count':len(chunk),'sha256':hashlib.sha256(payload.encode()).hexdigest()})
manifest={'summary':summary,'chunks':chunk_meta}
manifest_payload=json.dumps(manifest,separators=(',',':'),ensure_ascii=False)+'\n'
(outdir/'manifest.json').write_text(manifest_payload)
mono=ROOT/'DIFFERENTIAL_RESULTS.json'
if mono.exists(): mono.unlink()
print(json.dumps(summary,indent=2))
